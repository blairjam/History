/* James Blair & John Carter
 * 3 - 16 - 15
 * Algorithms Project 2 : Topological Ordering
 */

package edu.uca.cub;

public class Edge {
    private String designation;

    public Edge(String designation) {
        this.designation = designation;
    }

    public String getDesignation() {
        return designation;
    }
}
