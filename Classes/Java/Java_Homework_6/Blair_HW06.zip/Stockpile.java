package edu.uca.cub.jblair;

/* Simple object to hold the amount of cannon balls and gun powder.
   Values will remain the same throughout the entire program.
 */

public class Stockpile {
    public static int ammo = 0;
    public static double powder = 0;
}
